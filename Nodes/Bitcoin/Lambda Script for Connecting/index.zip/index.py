from bitcoinrpc.authproxy import AuthServiceProxy, JSONRPCException

#hardcoded variables
rpc_un = "testuser"
rpc_pw = "testuser1"
host_ip = "34.230.31.170"

rpc_conn = AuthServiceProxy("http://%s:%s@%s:8332"%(rpc_un,rpc_pw,host_ip))

def handler(event,context):
    block_height = rpc_conn.betblockcount()
    return block_height
